import re
import json
import csv
import os
import requests
import shutil

def save_menu(menu_name):
    os.makedirs("images", exist_ok=True)
    source_name = menu_name + ".html"

    # Load options_config.csv into option_map
    option_map = {}
    option_config_name = f"options_config_{menu_name}.csv"
    with open(option_config_name, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, fieldnames=["group id", "group type", "title"])
        for row in reader:
            option_map[row["title"].strip()] = row["group id"].strip()

    with open(source_name, "r", encoding="utf-8") as f:
        html = f.read()

    # Extract items
    match_items = re.search(r'"items"\s*:\s*({)', html)
    if not match_items:
        print("❌ 'items' block not found.")
        exit()

    start_index = match_items.start(1)
    decoder = json.JSONDecoder()

    try:
        parsed_obj, _ = decoder.raw_decode(html[start_index:])
        print(f"✅ Extracted {len(parsed_obj)} menu items.")

        # Extract categories
        match_categories = re.search(r'"categories"\s*:\s*(\[\{.*?\}])\s*,', html, re.DOTALL)
        if not match_categories:
            print("❌ 'categories' block not found.")
            exit()

        categories = json.loads(match_categories.group(1))
        item_to_category = {}
        for cat in categories:
            for item_id in cat.get("itemIds", []):
                item_to_category[str(item_id)] = cat.get("name", "")

        # Extract modifierGroups
        match_modifiers = re.search(r'"modifierGroups"\s*:\s*(\[\{.*?}])', html, re.DOTALL)
        if not match_modifiers:
            print("❌ 'modifierGroups' block not found.")
            exit()

        modifier_groups = json.loads(match_modifiers.group(1))

        # Start writing output CSV
        filename = f"menu_{menu_name}.csv"
        with open(filename, "w", newline='', encoding="utf-8-sig") as csvfile:
            writer = csv.writer(csvfile)

            for idx, (item_id, item) in enumerate(parsed_obj.items(), start=1):
                name = item.get("name", "").strip()
                desc = (item.get("description") or "").strip()

                variations = item.get("variations", [])
                if variations:
                    base_price = variations[0].get("basePrice", "")
                    modifiers = variations[0].get("modifierGroupsIds", [])
                else:
                    base_price = ""
                    modifiers = []

                # Build modifier_str using mapped group ids
                group_ids = []
                for mod_id in modifiers:
                    # Find the group dict in the list with matching id
                    group = next((g for g in modifier_groups if g.get("id") == mod_id), None)
                    if group:
                        group_name = group.get("name", "").strip()
                        mapped_id = option_map.get(group_name)
                        if mapped_id:
                            group_ids.append(mapped_id)

                modifier_str = ",".join(group_ids)

                # Handle image
                image_name = ""
                if item.get("imageSources"):
                    image_path = item["imageSources"][0].get("path", "")
                    if image_path:
                        image_id = image_path.split("/")[-1].rsplit(".", 1)[0]  # remove extension
                        image_name = f"{image_id}.png"

                        # Ensure folder exists
                        image_folder = f"images_{menu_name}"
                        os.makedirs(image_folder, exist_ok=True)

                        # Define Cloudinary transformations
                        transformed_part = "c_fill,q_auto,ar_1:1,c_thumb,h_280,w_280/f_png,q_auto"
                        transformed_url = re.sub(
                            r"image/upload/[^/]+/",
                            f"image/upload/{transformed_part}/",
                            image_path
                        )

                        image_file_path = os.path.join(image_folder, image_name)
                        try:
                            response = requests.get(transformed_url, timeout=10)
                            if response.status_code == 200:
                                with open(image_file_path, "wb") as img_file:
                                    img_file.write(response.content)
                            else:
                                print(f"⚠️  Image not found: {transformed_url}")
                        except Exception as e:
                            print(f"❌ Failed to download {image_name}: {e}")


                category_name = item_to_category.get(item_id, "")

                # Write CSV row
                writer.writerow([
                    idx, idx, "", "", "", "", name, "", desc,
                    base_price, base_price, "0", "0", "0",
                    modifier_str, "0", "0", "delivery,takeaway", "1",
                    image_name, "", "", "9", category_name, ""
                ])

        print(f"💾 Saved to {filename}")
        zip_name = f"images_{menu_name}"
        shutil.make_archive(zip_name, 'zip', f"images_{menu_name}")
        print(f"📦 Zipped image folder as {zip_name}.zip")
    except json.JSONDecodeError as e:
        print("❌ Failed to parse items JSON:", e)
